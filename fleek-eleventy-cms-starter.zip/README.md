# MagicTripHouse Catalogo - Eleventy + Netlify CMS + IPFS (Fleek) Starter

## Setup Locale
1. `npm install`
2. `npm run start` - avvia il server di sviluppo Eleventy

## Struttura
- **src/**: cartella di input Eleventy
  - **index.njk**: pagina principale
  - **_includes/layout.njk**: layout del sito
  - **sections/**: markdown delle sezioni (weed, filtrati, edibili, offerte, contatti)
- **admin/**: Netlify CMS
  - **index.html**: boilerplate
  - **config.yml**: configurazione CMS
- **style.css**: foglio di stile
- **img/**: metti qui le tue immagini (logo.png, greenpoison.jpg, dubai.jpg, vape.jpg)
- **.fleek.json**: configurazione build per Fleek

## Modifica Contenuti
Con Netlify CMS via browser:
1. Vai su `https://<your-site>.fleek.co/admin`
2. Loggati con l’account autorizzato (Identity/Git Gateway)
3. Modifica le sezioni in modo WYSIWYG, salva per rigenerare e ridistribuire

## Deploy su Fleek (IPFS)
1. Installa il Fleek CLI:
   ```bash
   npm install -g @fleek-platform/cli
   ```
2. Fai login:
   ```bash
   fleek login
   ```
3. Inizializza il sito:
   ```bash
   fleek sites init
   ```
4. Conferma build command e publicDir (preimpostati in .fleek.json)
5. Deploy:
   ```bash
   fleek sites deploy
   ```
6. Ottieni l’URL IPFS (es. https://ipfs.io/ipfs/QmXYZ...) o usa https://<your-site>.fleek.co

Ogni deploy aggiorna dist/ su IPFS e il sito è live.

