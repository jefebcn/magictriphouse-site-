---
section_id: edibili
title: "🌍🍫 DUBAI CHOCOLATE 73u (✅)"
---
- 10g 👉 95€
- 15g 👉 125€
- 20g 👉 165€
- 30g 👉 230€
- 50g 👉 370€
- 100g 👉 700€
