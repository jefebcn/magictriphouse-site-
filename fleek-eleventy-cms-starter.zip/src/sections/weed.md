---
section_id: weed
title: "🌴 GREEN POISON (✅)"
---
Tipologia: 🏠 INDOOR

- 10g 👉 90€
- 15g 👉 125€
- 20g 👉 160€
- 30g 👉 225€
- 50g 👉 375€
- 100g 👉 675€
- 200g 👉 1300€
- 500g 👉 3125€
